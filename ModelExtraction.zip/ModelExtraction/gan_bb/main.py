import torch 
import time 
import os 
import numpy as np 

def main():
    g= 