# ModelExtraction
Inter-IIT Code 2022
